<form method="post" action="/">
    <div class="row mt-4">
        <?php echo csrf_field(); ?>
        <div class="col-2">
            <label for="city_id">Select City:</label>
            <select name="city_id" class="form-control">
                <option value="">Select City</option>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->city_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-2">
            <label for="from">From:</label>
            <div class="input-group">
                <input type="date" class="form-control" value="12.03.2022" name="from" id="from">
                <div class="input-group-addon">
                    <span class="glyphicon glyphicon-th"></span>
                </div>
            </div>
        </div>
        <div class="col-2">
            <label for="to">To:</label>
            <div class="input-group">
                <input type="date" class="form-control" name="to" id="to">
                <div class="input-group-addon">
                    <span class="glyphicon glyphicon-th"></span>
                </div>
            </div>
        </div>
        <div class="col-2">
            <label for="temperature">Temperature:</label>
            <input type="number" class="form-control" name="temperature" id="temperature">
        </div>
        <div class="col-2">
            <label for="feel">Feel:</label>
            <input type="number" class="form-control" name="feel" id="feel">
        </div>
        <div class="col-2">
            <button type="submit" class="btn btn-secondary mt-4">Filter</button>
        </div>
    </div>
</form>
<table class="table table-striped mt-4">
    <thead>
    <tr>
        <th>ID</th>
        <th>City</th>
        <th>coordinates</th>
        <th>weather</th>
        <th>temperature</th>
        <th>feel</th>
        <th>humidity</th>
        <th>wind</th>
        <th>DateTime</th>
        <?php if(auth()->guard()->check()): ?>
            <th>Action</th>
        <?php endif; ?>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $weather; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($w->id); ?></td>
            <td><?php echo e($w->city->city_name); ?></td>
            <td><?php echo e($w->coordinates); ?></td>
            <td><?php echo e($w->weather); ?></td>
            <td><?php echo e($w->temperature); ?></td>
            <td><?php echo e($w->feel); ?></td>
            <td><?php echo e($w->humidity); ?></td>
            <td><?php echo e($w->wind); ?></td>
            <td><?php echo e($w->updated_at); ?></td>
            <?php if(auth()->guard()->check()): ?>
                <td>
                    <a href="#" class="btn btn-link"
                       onclick="editBtn(<?php echo e($w->id); ?>)">Edit</a>
                </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="d-flex">
    <?php echo $weather->links(); ?>

</div>
<?php echo $__env->make('edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/weatherapp/resources/views/components/table-weather.blade.php ENDPATH**/ ?>